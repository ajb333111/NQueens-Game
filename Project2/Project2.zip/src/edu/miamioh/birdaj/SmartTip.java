package edu.miamioh.birdaj;

// Alec Bird
// CSE 271 Section B

import javax.swing.JButton;

/**
 * 
 * Describes the function smart tip button
 *
 */
public class SmartTip extends JButton{

	/**
	 * Creates a smart tip button
	 * @param text the text on the button
	 */
	public SmartTip(String text){
		super(text);
	}
}
